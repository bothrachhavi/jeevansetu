---
name: JeevanSetu Design System
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#5c403c'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#916f6b'
  outline-variant: '#e6bdb8'
  surface-tint: '#bf0715'
  primary: '#b70011'
  on-primary: '#ffffff'
  primary-container: '#dc2626'
  on-primary-container: '#fff6f5'
  inverse-primary: '#ffb4ab'
  secondary: '#555f6f'
  on-secondary: '#ffffff'
  secondary-container: '#d6e0f3'
  on-secondary-container: '#596373'
  tertiary: '#00682b'
  on-tertiary: '#ffffff'
  tertiary-container: '#008438'
  on-tertiary-container: '#e7ffe4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000b'
  secondary-fixed: '#d9e3f6'
  secondary-fixed-dim: '#bdc7d9'
  on-secondary-fixed: '#121c2a'
  on-secondary-fixed-variant: '#3d4756'
  tertiary-fixed: '#7ffc97'
  tertiary-fixed-dim: '#62df7d'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005320'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  xxxl: 64px
---

## Brand & Style

The design system is engineered to facilitate a high-stakes emergency blood response environment. The brand personality is **reliable, urgent yet calm, and deeply human**. It balances the clinical precision of a medical platform with the modern, approachable aesthetic of a mission-driven startup.

The design style follows a **Modern Healthcare Minimalism** approach:
- **Cleanliness:** High use of whitespace to reduce cognitive load during emergencies.
- **Trust:** A professional aesthetic that prioritizes clarity and high-fidelity execution.
- **Softness:** Utilizing subtle shadows and rounded geometries to avoid a cold, institutional feel.
- **Accessibility:** High-contrast ratios and clear visual hierarchies ensure the UI is usable by diverse demographics under stress.

## Colors

The palette is designed to signal urgency without inducing panic.

- **Primary Red (#DC2626):** Reserved for high-priority actions, blood types, and emergency alerts. It is the "Life" color of the design system.
- **Dark Navy (#1F2937):** Used for primary typography and navigation elements to provide a grounded, professional foundation.
- **Success Green (#16A34A):** Signals completed donations, verified donors, and safe status updates.
- **Light Gray (#F9FAFB):** The primary background color to ensure the UI feels airy and distinctive from pure white "paper" surfaces.
- **Neutral/Surface:** White (#FFFFFF) is used for cards and interactive containers to create a clear "layered" effect against the light gray background.

## Typography

Note: *Plus Jakarta Sans* is used as a contemporary substitute for Poppins to provide a more modern, premium healthcare feel while maintaining the required geometric friendliness.

- **Headlines:** Use Plus Jakarta Sans with tighter letter spacing for a "designed" and authoritative look.
- **Body:** Inter is the workhorse for all functional data, donor details, and instructions, ensuring maximum legibility across all device types.
- **Hierarchy:** Ensure a clear distinction between "Display" types for marketing/impact stats and "Headline" types for functional app navigation.

## Layout & Spacing

The design system utilizes a strict **8px Grid System**. All dimensions, padding, and margins must be multiples of 8 (or 4 for micro-adjustments).

- **Layout Model:** 12-column fluid grid for desktop (max-width 1280px), 8-column for tablet, and 4-column for mobile.
- **Gutters:** Fixed at 24px for desktop to provide breathing room, 16px for mobile.
- **Margins:** 32px on desktop, 16px on mobile to maximize screen real estate for critical data.
- **Rhythm:** Vertical rhythm should follow the spacing scale, using `xxl` (48px) to separate major sections and `md` (16px) for internal component spacing.

## Elevation & Depth

This design system uses **Tonal Layering** combined with **Ambient Shadows** to create a structured, tactile hierarchy.

1.  **Level 0 (Base):** Light Gray (#F9FAFB). All background surfaces.
2.  **Level 1 (Card):** White (#FFFFFF) surface with a very soft, diffused shadow (`0px 4px 20px rgba(31, 41, 55, 0.04)`). Used for the majority of content containers.
3.  **Level 2 (Interactive/Hover):** White surface with a slightly deeper shadow (`0px 8px 30px rgba(31, 41, 55, 0.08)`). Used for hovered buttons or active cards.
4.  **Level 3 (Overlay):** Modals and dropdowns. Uses a crisp border (1px #E5E7EB) and a significant shadow to separate from the main UI.

Avoid heavy black shadows; instead, use shadows tinted with the Dark Navy secondary color at very low opacities.

## Shapes

The shape language is **Softly Rounded**, moving away from clinical sharpness to evoke a sense of care and community.

- **Standard Elements (Buttons, Inputs):** 0.5rem (8px) radius.
- **Containers (Cards, Modals):** 1rem (16px) radius.
- **Small Elements (Tags, Badges):** 0.25rem (4px) or full pill-shaped depending on the context.

## Components

### Buttons
- **Primary:** Solid Primary Red with white text. High emphasis.
- **Secondary:** Solid Dark Navy with white text. Used for secondary administrative tasks.
- **Ghost/Outline:** 1px border of Dark Navy or Red. Used for less urgent actions.
- **Sizing:** Large (56px height) for mobile tap targets; Medium (48px) for desktop.

### Cards
- Always White (#FFFFFF) on the Light Gray background.
- 16px internal padding.
- Used for Donor Profiles, Hospital Requests, and Blood Inventory stats.

### Inputs
- **Style:** 1px Light Gray border, 8px corner radius.
- **Focus State:** 2px solid Primary Red or Navy border with a 4px soft outer glow.
- **Labels:** Must use `label-md` (Inter SemiBold) placed above the field.

### Blood Type Chips
- Distinctive circular or rounded-rect badges.
- Use Primary Red background with white text for "Positive" types and a slightly lighter red or outline for "Negative" types to ensure clear distinction at a glance.

### Status Indicators
- Use Success Green for "Available" or "Fulfilled".
- Use Primary Red for "Urgent" or "Critical".
- Use Warning Amber for "Pending" or "Low Stock".